#include<iostream>
using namespace std;

int main()
{
    int k;
    string a="P:;L>sAkWaLW]9kqWl(W`9f;DWAfW^dY_u";
    for(int i=0;i<=33;i++)
    {
        a[i]+=8;
    }
    cout<<a;
}