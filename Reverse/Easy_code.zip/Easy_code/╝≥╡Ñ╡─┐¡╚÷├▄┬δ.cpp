#include<iostream>
using namespace std;

string Caesar_Cipher(string a)
{
    int k;
    for (int i = 0; i <=33; i++)
    {
        /* code */
        
        a[i]-=8;
    }
    return a;
}



int main()
{
    string str;
    cout<<"please input your password:"<<endl;
    string a,b;
    cin>>a;
    while (1)
    {
        /* code */
        if(a.length()!=34)
        {
            cout<<"try again������"<<endl;
            cin>>a;
        }
        else
        {
            break;
        }
    }
    b=Caesar_Cipher(a);
    cout<<b<<endl;
    str="P:;L>sAkWaLW]9kqWl(W`9f;DWAfW^dY_u";
    if(b==str)
    {
        cout<<"Yes,This is the flag for this problem";
    }
    else
    {
        cout<<"Sorry again";
    }
    return 0;
}