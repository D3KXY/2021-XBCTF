#include<iostream>
using namespace std;

int main()
{
    string a,b;
    cout<<"�����뱾�α���������:"<<endl;
    cin>>a;
    b="XBCTF";
    while (1)
    {
        /* code */
        if(a==b)
        {
            cout<<"Welcome to XBCTF"<<endl;
            cout<<"The flag is XBCTF{WElc0M_T0_X13CTf_ACbug}";
            break;
        }
        else
        {
            cout<<"try again";
        }
    }
    return 0;
}
